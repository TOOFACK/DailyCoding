package Sprint3_review;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;

public class Anew {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int temp = Integer.parseInt(br.readLine());

        String s = br.readLine();
        String[] mas = s.split(" ");
        int len =0;

        Arrays.sort(mas, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                String v1 = o1 + o2;
                String v2 = o2 + o1;
                return Integer.compare(Integer.parseInt(v2), Integer.parseInt(v1));
            }
        });

        for(String t : mas){
            System.out.print(t);
        }


    }





}
